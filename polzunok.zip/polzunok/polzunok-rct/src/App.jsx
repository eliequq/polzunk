import { useState } from 'react'
 
import './App.css'
 
 const RangeSlider = () => {
   
  const [value, setValue] = useState(0);
  const handleChange = (e) => {
    setValue(parseFloat(e.target.value));
  };
    const [selectedValue, setSelectedValue] = useState('0.01');
    const handleSelectChange = (e) => {
      setSelectedValue(e.target.value);  
    };
     

  return (
    <div style={{ padding: '20px' }}>
       
      <input
        type="range"
        min="-1000"
        max="1000"
        step= {selectedValue}
        value={value}
        onChange={handleChange}
        style={{ width: '100%' }}
      />
      <div>
        <span>Scale {value}</span>
      </div>
      <div style={{ padding: '20px' }}>
     
      
      <select scale={selectedValue} onChange={handleSelectChange}>
      <option value="" disabled>Выберите значение</option>
        <option scale="0.01">0.01</option>
        <option scale="0.1">0.1</option>
        <option scale="1">1</option>
        <option scale="10">10</option>
        <option scale="100">100</option>
        <option scale="1000">1000</option>
      </select>
      
      <div>
        <span> Value {selectedValue}</span>
      </div>
    </div>
    </div>
  );
};

export default RangeSlider;